#!/bin/bash

################################################################################
# SAM3 Multi-GPU Distributed Execution Script
# GPU별로 독립적으로 작업 분산 실행
################################################################################

# ========== 기본 설정 ==========
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_SCRIPT="${SCRIPT_DIR}/sam3_offline.py"
MODEL_DIR="${SCRIPT_DIR}/models"
LOG_DIR="${SCRIPT_DIR}/logs"

# 로그 디렉토리 생성
mkdir -p "${LOG_DIR}"

# ========== 사용자 설정 ==========
# GPU 리스트 (사용할 GPU 인덱스)
GPU_LIST=(0 1 2 3)

# 데이터 경로
IMAGE_DIR="${SCRIPT_DIR}/data/images"
LABEL_DIR="${SCRIPT_DIR}/data/labels"
VIZ_DIR="${SCRIPT_DIR}/data/results"

# 동영상 처리 (옵션)
VIDEO_SOURCE=""  # 예: "${SCRIPT_DIR}/data/videos"
FPS_EXTRACTION=1
JPEG_DIR="${SCRIPT_DIR}/data/JPEGImages"

# 클래스 설정
CLASSES="person:0,car:1,bicycle:2"

# 추론 설정
THRESHOLD=0.3
CHUNK_SIZE=4

# 표시 옵션
SHOW_REALTIME=false
SAVE_VISUALIZATION=true

# ========== 색상 코드 ==========
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ========== 함수 정의 ==========

print_header() {
    echo -e "${CYAN}================================================================${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}================================================================${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

# GPU 개수 확인
check_gpu_count() {
    if ! command -v nvidia-smi &> /dev/null; then
        print_error "nvidia-smi를 찾을 수 없습니다. CUDA가 설치되어 있나요?"
        exit 1
    fi
    
    GPU_COUNT=$(nvidia-smi --list-gpus | wc -l)
    
    if [ $GPU_COUNT -eq 0 ]; then
        print_error "사용 가능한 GPU가 없습니다."
        exit 1
    fi
    
    print_success "감지된 GPU: ${GPU_COUNT}개"
}

# 이미지 분할 함수
split_images() {
    local image_dir=$1
    local num_gpus=$2
    local output_dir=$3
    
    print_info "이미지 파일 분할 중..."
    
    # 임시 리스트 파일 생성
    local temp_list="${output_dir}/all_images.txt"
    find "${image_dir}" -type f \( -iname "*.jpg" -o -iname "*.jpeg" -o -iname "*.png" -o -iname "*.bmp" \) > "${temp_list}"
    
    local total_images=$(wc -l < "${temp_list}")
    print_info "총 이미지: ${total_images}개"
    
    if [ $total_images -eq 0 ]; then
        print_error "이미지를 찾을 수 없습니다: ${image_dir}"
        return 1
    fi
    
    # GPU별로 분할
    local images_per_gpu=$((total_images / num_gpus))
    local remainder=$((total_images % num_gpus))
    
    print_info "GPU당 할당: 약 ${images_per_gpu}개"
    
    local start_line=1
    for ((i=0; i<num_gpus; i++)); do
        local count=$images_per_gpu
        
        # 나머지를 앞쪽 GPU에 분배
        if [ $i -lt $remainder ]; then
            count=$((count + 1))
        fi
        
        local gpu_list="${output_dir}/gpu_${i}_images.txt"
        sed -n "${start_line},$((start_line + count - 1))p" "${temp_list}" > "${gpu_list}"
        
        print_success "GPU ${i}: ${count}개 이미지 → ${gpu_list}"
        
        start_line=$((start_line + count))
    done
    
    rm "${temp_list}"
}

# 동영상 분할 함수
split_videos() {
    local video_dir=$1
    local num_gpus=$2
    local output_dir=$3
    
    print_info "동영상 파일 분할 중..."
    
    # 임시 리스트 파일 생성
    local temp_list="${output_dir}/all_videos.txt"
    find "${video_dir}" -type f \( -iname "*.mp4" -o -iname "*.avi" -o -iname "*.mov" -o -iname "*.mkv" \) > "${temp_list}"
    
    local total_videos=$(wc -l < "${temp_list}")
    print_info "총 동영상: ${total_videos}개"
    
    if [ $total_videos -eq 0 ]; then
        print_error "동영상을 찾을 수 없습니다: ${video_dir}"
        return 1
    fi
    
    # GPU별로 분할
    local videos_per_gpu=$((total_videos / num_gpus))
    local remainder=$((total_videos % num_gpus))
    
    print_info "GPU당 할당: 약 ${videos_per_gpu}개"
    
    local start_line=1
    for ((i=0; i<num_gpus; i++)); do
        local count=$videos_per_gpu
        
        if [ $i -lt $remainder ]; then
            count=$((count + 1))
        fi
        
        local gpu_list="${output_dir}/gpu_${i}_videos.txt"
        sed -n "${start_line},$((start_line + count - 1))p" "${temp_list}" > "${gpu_list}"
        
        print_success "GPU ${i}: ${count}개 동영상 → ${gpu_list}"
        
        start_line=$((start_line + count))
    done
    
    rm "${temp_list}"
}

# GPU별 프로세스 실행
run_gpu_process() {
    local gpu_id=$1
    local input_source=$2
    local log_file="${LOG_DIR}/gpu_${gpu_id}.log"
    
    print_info "GPU ${gpu_id} 프로세스 시작..."
    
    # Python 명령 구성
    local cmd="python ${PYTHON_SCRIPT}"
    cmd="${cmd} --gpu ${gpu_id}"
    cmd="${cmd} --model_dir ${MODEL_DIR}"
    cmd="${cmd} --image_dir ${input_source}"
    cmd="${cmd} --label_dir ${LABEL_DIR}"
    cmd="${cmd} --classes \"${CLASSES}\""
    cmd="${cmd} --threshold ${THRESHOLD}"
    cmd="${cmd} --chunk_size ${CHUNK_SIZE}"
    
    if [ "${SAVE_VISUALIZATION}" = true ]; then
        cmd="${cmd} --save_viz --viz_dir ${VIZ_DIR}"
    fi
    
    if [ "${SHOW_REALTIME}" = true ]; then
        cmd="${cmd} --show"
    fi
    
    # 백그라운드 실행
    echo "Starting: ${cmd}" > "${log_file}"
    eval "${cmd}" >> "${log_file}" 2>&1 &
    
    local pid=$!
    echo $pid > "${LOG_DIR}/gpu_${gpu_id}.pid"
    
    print_success "GPU ${gpu_id} PID: ${pid}"
}

# 프로세스 모니터링
monitor_processes() {
    local num_gpus=$1
    
    print_header "프로세스 모니터링"
    
    local all_done=false
    while [ "$all_done" = false ]; do
        all_done=true
        
        echo ""
        echo "$(date '+%Y-%m-%d %H:%M:%S') - 상태 확인"
        echo "----------------------------------------"
        
        for ((i=0; i<num_gpus; i++)); do
            local pid_file="${LOG_DIR}/gpu_${i}.pid"
            
            if [ -f "${pid_file}" ]; then
                local pid=$(cat "${pid_file}")
                
                if ps -p $pid > /dev/null 2>&1; then
                    echo -e "${GREEN}GPU ${i}: 실행중 (PID: ${pid})${NC}"
                    all_done=false
                else
                    echo -e "${YELLOW}GPU ${i}: 완료 (PID: ${pid})${NC}"
                fi
            else
                echo -e "${RED}GPU ${i}: PID 파일 없음${NC}"
            fi
        done
        
        if [ "$all_done" = false ]; then
            sleep 10
        fi
    done
    
    print_success "모든 GPU 프로세스 완료!"
}

# 결과 요약
print_summary() {
    print_header "실행 결과 요약"
    
    for ((i=0; i<${#GPU_LIST[@]}; i++)); do
        local gpu_id=${GPU_LIST[$i]}
        local log_file="${LOG_DIR}/gpu_${gpu_id}.log"
        
        echo ""
        echo "GPU ${gpu_id} 결과:"
        echo "----------------------------------------"
        
        if [ -f "${log_file}" ]; then
            # 로그에서 주요 정보 추출
            grep -E "(성공|실패|총 객체|소요 시간)" "${log_file}" | tail -10
        else
            print_error "로그 파일을 찾을 수 없습니다: ${log_file}"
        fi
    done
    
    echo ""
    print_info "자세한 로그: ${LOG_DIR}"
}

# 프로세스 종료
cleanup() {
    print_warning "프로세스 종료 중..."
    
    for pid_file in "${LOG_DIR}"/*.pid; do
        if [ -f "${pid_file}" ]; then
            local pid=$(cat "${pid_file}")
            if ps -p $pid > /dev/null 2>&1; then
                kill -TERM $pid 2>/dev/null
                print_info "프로세스 종료: PID ${pid}"
            fi
            rm "${pid_file}"
        fi
    done
    
    print_success "정리 완료"
    exit 0
}

# ========== 메인 실행 ==========

main() {
    print_header "SAM3 Multi-GPU Distributed Execution"
    
    # Ctrl+C 처리
    trap cleanup SIGINT SIGTERM
    
    # 환경 확인
    print_header "환경 확인"
    
    if [ ! -f "${PYTHON_SCRIPT}" ]; then
        print_error "Python 스크립트를 찾을 수 없습니다: ${PYTHON_SCRIPT}"
        exit 1
    fi
    print_success "Python 스크립트: ${PYTHON_SCRIPT}"
    
    if [ ! -d "${MODEL_DIR}" ]; then
        print_error "모델 디렉토리를 찾을 수 없습니다: ${MODEL_DIR}"
        exit 1
    fi
    print_success "모델 디렉토리: ${MODEL_DIR}"
    
    check_gpu_count
    
    # GPU 리스트 확인
    local num_gpus=${#GPU_LIST[@]}
    print_info "사용할 GPU: ${GPU_LIST[*]} (총 ${num_gpus}개)"
    
    # 출력 디렉토리 생성
    mkdir -p "${LABEL_DIR}"
    mkdir -p "${VIZ_DIR}"
    
    # ========== 동영상 처리 (옵션) ==========
    if [ -n "${VIDEO_SOURCE}" ] && [ -d "${VIDEO_SOURCE}" ]; then
        print_header "동영상 프레임 추출 (GPU별 분산)"
        
        # 동영상 분할
        split_videos "${VIDEO_SOURCE}" ${num_gpus} "${LOG_DIR}"
        
        # GPU별 프레임 추출 실행
        for ((i=0; i<num_gpus; i++)); do
            local gpu_id=${GPU_LIST[$i]}
            local video_list="${LOG_DIR}/gpu_${i}_videos.txt"
            local gpu_jpeg_dir="${JPEG_DIR}/gpu_${gpu_id}"
            
            mkdir -p "${gpu_jpeg_dir}"
            
            # 프레임 추출은 순차 실행 (너무 많은 프로세스 방지)
            print_info "GPU ${gpu_id}: 프레임 추출 중..."
            
            while IFS= read -r video_path; do
                python ${PYTHON_SCRIPT} \
                    --gpu ${gpu_id} \
                    --video_source "${video_path}" \
                    --fps ${FPS_EXTRACTION} \
                    --jpeg_dir "${gpu_jpeg_dir}" \
                    >> "${LOG_DIR}/gpu_${gpu_id}_extract.log" 2>&1
            done < "${video_list}"
            
            print_success "GPU ${gpu_id}: 프레임 추출 완료"
        done
        
        # 모든 프레임을 통합된 IMAGE_DIR로 설정
        IMAGE_DIR="${JPEG_DIR}"
    fi
    
    # ========== 이미지 처리 ==========
    print_header "이미지 처리 (GPU별 분산)"
    
    if [ ! -d "${IMAGE_DIR}" ]; then
        print_error "이미지 디렉토리를 찾을 수 없습니다: ${IMAGE_DIR}"
        exit 1
    fi
    
    # 이미지 분할
    split_images "${IMAGE_DIR}" ${num_gpus} "${LOG_DIR}"
    
    # GPU별 프로세스 실행
    print_header "GPU 프로세스 실행"
    
    for ((i=0; i<num_gpus; i++)); do
        local gpu_id=${GPU_LIST[$i]}
        local image_list="${LOG_DIR}/gpu_${i}_images.txt"
        
        run_gpu_process ${gpu_id} "${image_list}"
        
        # 프로세스 시작 간격 (GPU 초기화 시간)
        sleep 2
    done
    
    echo ""
    print_success "모든 GPU 프로세스 시작 완료!"
    print_info "로그 디렉토리: ${LOG_DIR}"
    
    # 프로세스 모니터링
    monitor_processes ${num_gpus}
    
    # 결과 요약
    print_summary
    
    print_header "완료!"
    print_success "라벨 저장 위치: ${LABEL_DIR}"
    if [ "${SAVE_VISUALIZATION}" = true ]; then
        print_success "시각화 저장 위치: ${VIZ_DIR}"
    fi
}

# 스크립트 실행
main "$@"
